﻿using EvoAPI.Data;
using EvoAPI.Models;
using Microsoft.AspNetCore.Mvc;

namespace EvoAPI.Controllers
{
    [ApiController]
    [Route("api/departamentos")]
    public class DepartamentosController : Controller
    {
        private readonly IDepartamentoRepository _departamentoRepository;
        private readonly IFuncionarioRepository _funcionarioRepository;
        private readonly DataContext _context;

        public DepartamentosController(IDepartamentoRepository departamentoRepository, IFuncionarioRepository funcionarioRepository, DataContext context)
        {
            _departamentoRepository = departamentoRepository;
            _funcionarioRepository = funcionarioRepository;
            _context = context;
        }

        [HttpGet]
        public IEnumerable<Departamento> Get()
        {
            return _departamentoRepository.GetAll();
        }

        [HttpGet("{id:int}")]
        public Departamento GetById(int id)
        {
            return _departamentoRepository.GetById(id);
        }

        [HttpPost]
        public void Create([FromBody] Departamento departamento)
        {
            _departamentoRepository.Create(departamento);
        }

        [HttpPut("{id:int}")]
        public void Update([FromBody] Departamento departamento)
        {
            _departamentoRepository.Update(departamento);
        }

        [HttpDelete("{id:int}")]
        public void Delete(int id)
        {
            //excluir os funcionarios do departamento 
            _funcionarioRepository.ExcluirPorDepartamento(id);

            _departamentoRepository.Delete(id);
        }
    }
}
