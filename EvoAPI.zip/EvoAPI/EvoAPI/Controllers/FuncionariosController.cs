﻿namespace EvoAPI.Controllers
{
    using EvoAPI.Data;
    using EvoAPI.Models;
    using Microsoft.AspNetCore.Mvc;
    using System.Collections.Generic;

    [ApiController]
    [Route("api/funcionarios")]
    public class FuncionariosController : Controller
    {
        private readonly IFuncionarioRepository _funcionarioRepository;

        public FuncionariosController(IFuncionarioRepository funcionarioRepository)
        {
            _funcionarioRepository = funcionarioRepository;
        }

        [HttpGet]
        public IEnumerable<Funcionario> Get()
        {
            return _funcionarioRepository.GetAll();
        }

        [HttpGet("{id:int}")]
        public Funcionario GetById(int id)
        {
            return _funcionarioRepository.GetById(id);
        }

        [HttpGet("departamento/{departamentoId:int}")]
        public IEnumerable<Funcionario> GetByDepartamento(int departamentoId)
        {
            return _funcionarioRepository.GetByDepartamento(departamentoId);
        }

        [HttpPost]
        public void Create([FromBody] Funcionario funcionario)
        {
            _funcionarioRepository.Create(funcionario);
        }

        [HttpPut("{id:int}")]
        public void Update([FromBody] Funcionario funcionario)
        {
            _funcionarioRepository.Update(funcionario);
        }

        [HttpDelete("{id:int}")]
        public void Delete(int id)
        {
            _funcionarioRepository.Delete(id);
        }


    }
}
