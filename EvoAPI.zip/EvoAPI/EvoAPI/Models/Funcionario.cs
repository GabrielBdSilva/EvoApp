﻿using System.ComponentModel.DataAnnotations.Schema;
using System.ComponentModel.DataAnnotations;

namespace EvoAPI.Models
{
    public class Funcionario
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)] 
        public int Id { get; set; }
        public string Nome { get; set; }
        public string Foto { get; set; }
        public string RG { get; set; }
        public int DepartamentoId { get; set; }

        //public virtual Departamento Departamento { get; set; }
    }
}
