﻿using EvoAPI.Models;

namespace EvoAPI.Data
{
    public interface IDepartamentoRepository
    {
        IEnumerable<Departamento> GetAll();
        Departamento GetById(int id);
        void Create(Departamento departamento);
        void Update(Departamento departamento);
        void Delete(int id);
    }
    public interface IFuncionarioRepository
    {
        IEnumerable<Funcionario> GetAll();
        Funcionario GetById(int id);
        IEnumerable<Funcionario> GetByDepartamento(int departamentoId);
        void Create(Funcionario funcionario);
        void Update(Funcionario funcionario);
        void Delete(int id);
        void ExcluirPorDepartamento(int departamentoId);
    }

}
