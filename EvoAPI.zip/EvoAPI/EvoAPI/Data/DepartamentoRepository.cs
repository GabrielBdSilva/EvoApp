﻿namespace EvoAPI.Data
{
    using Microsoft.EntityFrameworkCore;
    using EvoAPI.Models;

    public class DepartamentoRepository : IDepartamentoRepository
    {
        private readonly DataContext _context;

        public DepartamentoRepository(DataContext context)
        {
            _context = context;
        }

        public IEnumerable<Departamento> GetAll()
        {
            return _context.Departamentos.ToList();
        }

        public Departamento GetById(int id)
        {
            return _context.Departamentos.Find(id);
        }

        public void Create(Departamento departamento)
        {
            _context.Departamentos.Add(departamento);
            _context.SaveChanges();
        }

        public void Update(Departamento departamento)
        {
            _context.Departamentos.Update(departamento);
            _context.SaveChanges();
        }

        public void Delete(int id)
        {
            Departamento departamento = _context.Departamentos.Find(id);
            _context.Departamentos.Remove(departamento);
            _context.SaveChanges();
        }
    }

}
