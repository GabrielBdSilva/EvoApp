﻿using System.Collections.Generic;
using System.Linq;
using EvoAPI.Models;

namespace EvoAPI.Data
{
    public class FuncionarioRepository : IFuncionarioRepository
    {
        private readonly DataContext _context;

        public FuncionarioRepository(DataContext context)
        {
            _context = context;
        }

        public IEnumerable<Funcionario> GetAll()
        {
            return _context.Funcionarios.ToList();
        }

        public Funcionario GetById(int id)
        {
            return _context.Funcionarios.Find(id);
        }

        public IEnumerable<Funcionario> GetByDepartamento(int departamentoId)
        {
            return _context.Funcionarios.Where(f => f.DepartamentoId == departamentoId).ToList();
        }

        public void Create(Funcionario funcionario)
        {
            _context.Funcionarios.Add(funcionario);
            _context.SaveChanges();
        }

        public void Update(Funcionario funcionario)
        {
            _context.Funcionarios.Update(funcionario);
            _context.SaveChanges();
        }

        public void Delete(int id)
        {
            var funcionario = _context.Funcionarios.Find(id);
            if (funcionario != null)
            {
                _context.Funcionarios.Remove(funcionario);
                _context.SaveChanges();
            }
        }

        public void ExcluirPorDepartamento(int departamentoId)
        {
            var funcionarios = _context.Funcionarios.Where(f => f.DepartamentoId == departamentoId);
            _context.Funcionarios.RemoveRange(funcionarios);
            _context.SaveChanges();
        }
    }
}